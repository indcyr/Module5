vuser_end()
{

	/* Logout */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.5");

	web_submit_data("logout",
		"Action=https://www.blazedemo.com/logout",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://www.blazedemo.com/home",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=_token", "Value=7ISuOmMA3z5Tu7gD68uG4PHXY9SbiMaBGGUXCUvw", ENDITEM,
		LAST);

	web_custom_request("pageviews_2",
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageviews?api_key={api_key}",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://www.blazedemo.com/",
		"Snapshot=t8.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"cdef24d1-0aeb-47f7-b7fc-0f7f2a8ba766\",\"iso_time_full\":\"2024-02-24T04:30:34.513Z\",\"local_time_full\":\"Sat Feb 24 2024 10:00:34 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"4dbdeb68-0865-4cf1-a71e-1de29a8aeed7\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"26a3de79-39cc-453f-9c7f-8b997735f356\",\"tracker_loaded_at\":\"2024-02-24T04:30:34.512Z\",\"prodperfect_test_data\":null,\"user\":{\"uuid\":\"084e356d-9f46-43b1-9dc2-273bb37cc725\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":595,\"pixel_max\":595,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":0,\"time_on_page_ms\":1},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\":\"Win32\",\"useragen"
		"t\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0\",\"version\":\"5.0 (Windows)\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":595,\"width\":1280,\"scrollHeight\":595,\"ratio\":{\"height\":0.88,\"width\":1}}}},\"url\":{\"full\":\"https://www.blazedemo.com/\",\"info\":{}},\"referrer\":{\"initial\":\"https://www.blazedemo.com/home\",\"full\":\"https://www.blazedemo.com/home\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-24T04:30:34.513Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"keen."
		"timestamp\"},\"output\":\"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}",
		LAST);

	return 0;
}