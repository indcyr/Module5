Action()
{

	/* Login */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_submit_data("validate",
		"Action=https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login",
		"Snapshot=t3.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=_token", "Value={_token}", ENDITEM,
		"Name=username", "Value={username}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		LAST);

	

	/* Out */

	web_url("punchIn", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);



	web_url("punchOut", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);


	return 0;
}
