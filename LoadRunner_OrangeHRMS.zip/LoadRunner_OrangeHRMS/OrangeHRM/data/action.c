Action()
{

	/* Login */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_submit_data("validate", 
		"Action=https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=43b6a7af2b6339730.ECAVFzmRQ1NBe1IJEiKrhiHSvaJxjyXMvnB2hRxiVlc.YxgtVFrhBT8zShhzKm70zmeGjc80yUq8xEIMqCUxYTJ8SyVCb94gHyIPMQ", ENDITEM, 
		"Name=username", "Value=Admin", ENDITEM, 
		"Name=password", "Value=admin123", ENDITEM, 
		LAST);

	web_url("time-at-work", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/time-at-work?timezoneOffset=5.5&currentDate=2024-02-26&currentTime=13:58", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("action-summary", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/action-summary", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("shortcuts", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/shortcuts", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("feed", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/buzz/feed?limit=5&offset=0&sortOrder=DESC&sortField=share.createdAtUtc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("leaves", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/leaves?date=2024-02-26", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("subunit", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/subunit", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("locations", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/locations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("push", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/events/push", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	/* Out */

	web_url("punchIn", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("current-datetime", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/current-datetime", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("holidays", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("latest", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/records/latest", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("holidays_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("overlaps", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/punch-out/overlaps?date=2024-02-26&time=14:05&timezoneOffset=5.5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("overlaps_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/punch-out/overlaps?date=2024-02-26&time=14:05&timezoneOffset=5.5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("overlaps_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/punch-out/overlaps?date=2024-02-26&time=14:05&timezoneOffset=5.5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("records", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/records", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"Body={\"date\":\"2024-02-26\",\"time\":\"14:05\",\"note\":null,\"timezoneOffset\":5.5,\"timezoneName\":\"Asia/Calcutta\"}", 
		LAST);

	web_url("punchOut", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchOut", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("holidays_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("current-datetime_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/current-datetime", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("holidays_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("overlaps_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/attendance/punch-in/overlaps?date=2024-02-26&time=14:05&timezoneOffset=5.5", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/attendance/punchIn", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
